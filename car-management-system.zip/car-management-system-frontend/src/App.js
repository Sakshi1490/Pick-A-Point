import "./App.css";
import { Route, Routes } from "react-router-dom";
import AboutUs from "./page/AboutUs";
import ContactUs from "./page/ContactUs";
import Header from "./NavbarComponent/Header";
import HomePage from "./page/HomePage";
import AddLocation from "./LocationComponent/AddLocation";
import AddFacility from "./FacilityComponent/AddFacility";
import AddParkingForm from "./ParkingComponent/AddParkingForm";
import UserRegister from "./UserComponent/UserRegister";
import Parking from "./ParkingComponent/Parking";
import AddParkingFacilities from "./FacilityComponent/AddParkingFacilities";
import AddParkingReview from "./ParkingReviewComponent/AddParkingReview";
import UserLoginForm from "./UserComponent/UserLoginForm";
import ViewAllBooking from "./BookingComponent/ViewAllBooking";
import ViewMyBooking from "./BookingComponent/ViewMyBooking";
import ViewMyParkingBookings from "./BookingComponent/ViewMyParkingBookings";
import VerifyBooking from "./BookingComponent/VerifyBooking";

function App() {
  return (
    <div>
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/home/all/parking/location" element={<HomePage />} />
        <Route
          path="/home/parking/location/:locationId/:locationName"
          element={<HomePage />}
        />
        <Route path="contact" element={<ContactUs />} />
        <Route path="about" element={<AboutUs />} />
        <Route path="admin/add-location" element={<AddLocation />} />
        <Route path="admin/add-facility" element={<AddFacility />} />
        <Route path="admin/parking/register" element={<AddParkingForm />} />
        <Route path="user/parking/register" element={<UserRegister />} />
        <Route path="user/customer/register" element={<UserRegister />} />
        <Route path="user/admin/register" element={<UserRegister />} />
        <Route path="/user/login" element={<UserLoginForm />} />
        <Route
          path="/home/parking/location/:locationId/:locationName"
          element={<HomePage />}
        />
        <Route
          path="parking/:parkingId/add/facility"
          element={<AddParkingFacilities />}
        />
        <Route
          path="parking/:parkingId/location/:locationId/add/review"
          element={<AddParkingReview />}
        />
        <Route
          path="/parking/:parkingId/location/:locationId"
          element={<Parking />}
        />
        <Route path="user/admin/booking/all" element={<ViewAllBooking />} />
        <Route path="user/parking/bookings" element={<ViewMyBooking />} />
        <Route
          path="user/parking/bookings/all"
          element={<ViewMyParkingBookings />}
        />
        <Route
          path="/parking/verify/booking/:bookingId"
          element={<VerifyBooking />}
        />
      </Routes>
    </div>
  );
}

export default App;
