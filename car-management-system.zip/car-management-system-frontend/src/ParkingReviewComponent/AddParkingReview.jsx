import { useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import ParkingCarousel from "../ParkingComponent/ParkingCarousel";
import { useParams } from "react-router-dom";
import axios from "axios";
import ParkingCard from "../ParkingComponent/ParkingCard";

const AddParkingReview = () => {
  let user = JSON.parse(sessionStorage.getItem("active-customer"));

  const [userId, setUserId] = useState(user.id);

  let { parkingId, locationId } = useParams();

  const [star, setStar] = useState("");
  const [review, setReview] = useState("");

  const [parkings, setParkings] = useState([]);

  const [parking, setParking] = useState({
    id: "",
    name: "",
    description: "",
    street: "",
    pincode: "",
    emailId: "",
    pricePerDay: "",
    totalRoom: "",
    image1: "",
    image2: "",
    image3: "",
    userId: "",
    location: { id: "", city: "", description: "" },
    facility: [{ id: "", name: "", description: "" }],
  });

  let navigate = useNavigate();

  const retrieveParking = async () => {
    const response = await axios.get(
      "http://localhost:8080/api/parking/id?parkingId=" + parkingId
    );

    return response.data;
  };

  useEffect(() => {
    const getParking = async () => {
      const retrievedParking = await retrieveParking();

      setParking(retrievedParking.parking);
    };

    const getParkingsByLocation = async () => {
      const allParkings = await retrieveParkingsByLocation();
      if (allParkings) {
        setParkings(allParkings.parkings);
      }
    };

    getParking();
    getParkingsByLocation();
  }, [parkingId]);

  const retrieveParkingsByLocation = async () => {
    console.log("Lets print location id here " + parking.location.id);

    const response = await axios.get(
      "http://localhost:8080/api/parking/location?locationId=" + locationId
    );
    console.log(response.data);
    return response.data;
  };

  const saveParkingReview = (e) => {
    if (user == null) {
      e.preventDefault();
      alert("Please login as Customer for adding your review!!!");
    } else {
      e.preventDefault();
      setUserId(user.id);
      let data = { userId, parkingId, star, review };

      fetch("http://localhost:8080/api/parking/review/add", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      }).then((result) => {
        result.json().then((res) => {
          console.log(res);
          navigate("/parking/" + parking.id + "/location/" + parking.location.id);
          console.log(res.responseMessage);
          toast.warn(res.responseMessage, {
            position: "top-center",
            autoClose: 1000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        });
      });
    }
  };

  return (
    <div className="container-fluid mb-5">
      <div class="row">
        <div class="col-sm-2 mt-2"></div>
        <div class="col-sm-3 mt-2">
          <div class="card form-card border-color custom-bg">
            <ParkingCarousel
              item={{
                image1: parking.image1,
                image2: parking.image2,
                image3: parking.image3,
              }}
            />
          </div>
        </div>

        <div class="col-sm-5 mt-2">
          <div
            className="card form-card border-color custom-bg"
            style={{ width: "30rem" }}
          >
            <div className="card-header bg-color text-center custom-bg-text">
              <h5 className="card-title">Add Parking Review</h5>
            </div>
            <div className="card-body text-color">
              <form onSubmit={saveParkingReview}>
                <div className="mb-3">
                  <label className="form-label">
                    <b>Star</b>
                  </label>

                  <select
                    name="locationId"
                    onChange={(e) => {
                      setStar(e.target.value);
                    }}
                    className="form-control"
                  >
                    <option value="">Select Star</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label htmlFor="review" className="form-label">
                    <b>Parking Review</b>
                  </label>
                  <textarea
                    className="form-control"
                    id="review"
                    rows="3"
                    placeholder="enter review.."
                    onChange={(e) => {
                      setReview(e.target.value);
                    }}
                    value={review}
                  />
                </div>

                <input
                  type="submit"
                  className="btn bg-color custom-bg-text"
                  value="Add Review"
                />

                <ToastContainer />
              </form>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-sm-12">
          <h2>Other Parkings in {parking.location.city} Location:</h2>
          <div className="row row-cols-1 row-cols-md-4 g-4">
            {parkings.map((h) => {
              return <ParkingCard item={h} />;
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddParkingReview;
