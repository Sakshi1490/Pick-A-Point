import Carousel from "./Carousel";
import GetAllLocations from "../LocationComponent/GetAllLocations";
import GetAllFacility from "../FacilityComponent/GetAllFacility";
import axios from "axios";
import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import ParkingCard from "../ParkingComponent/ParkingCard";
import Footer from "./Footer";

const HomePage = () => {
  const [parkings, setParkings] = useState([]);
  const { locationId } = useParams();

  useEffect(() => {
    const getAllParkings = async () => {
      const allParkings = await retrieveAllParkings();
      if (allParkings) {
        setParkings(allParkings.parkings);
      }
    };

    const getProductsByLocation = async () => {
      const allParkings = await retrieveProductsByLocation();
      if (allParkings) {
        setParkings(allParkings.parkings);
      }
    };

    if (locationId == null) {
      console.log("Location Id is null");
      getAllParkings();
    } else {
      console.log("Location Id is NOT null");
      getProductsByLocation();
    }
    // eslint-disable-next-line
  }, [locationId]);

  const retrieveAllParkings = async () => {
    const response = await axios.get("http://localhost:8080/api/parking/fetch");

    return response.data;
  };

  const retrieveProductsByLocation = async () => {
    const response = await axios.get(
      "http://localhost:8080/api/parking/location?locationId=" + locationId
    );

    return response.data;
  };

  return (
    <div className="container-fluid mb-2">
      <Carousel />
      <div className="mt-2 mb-5">
        <div className="row">
          <div className="col-md-2">
            <GetAllLocations />
          </div>
          <div className="col-md-8">
            <div className="row row-cols-1 row-cols-md-3 g-3">
              {parkings.map((parking) => {
                return <ParkingCard item={parking} />;
              })}
            </div>
          </div>
          <div className="col-md-2">
            <GetAllFacility />
          </div>
        </div>
      </div>
      <hr />
      <Footer />
    </div>
  );
};

export default HomePage;
