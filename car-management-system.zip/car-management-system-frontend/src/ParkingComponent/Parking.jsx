import GetAllLocations from "../LocationComponent/GetAllLocations";
import LocationNavigator from "../LocationComponent/LocationNavigator";
import { useParams } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import ParkingCard from "./ParkingCard";
import ParkingCarousel from "./ParkingCarousel";
import GetParkingFacilities from "../FacilityComponent/GetParkingFacilities";
import GetParkingReviews from "../ParkingReviewComponent/GetParkingReviews";
import { useNavigate } from "react-router-dom";
import Footer from "../page/Footer";

const Parking = () => {
  const { parkingId, locationId } = useParams();

  let user = JSON.parse(sessionStorage.getItem("active-customer"));
  let admin = JSON.parse(sessionStorage.getItem("active-admin"));

  const [quantity, setQuantity] = useState("");

  const [parkings, setParkings] = useState([]);

  let navigate = useNavigate();

  const [facilitiesToPass, setFacilitiesToPass] = useState([]);

  const [parking, setParking] = useState({
    id: "",
    name: "",
    description: "",
    street: "",
    pincode: "",
    emailId: "",
    pricePerDay: "",
    totalRoom: "",
    image1: "",
    image2: "",
    image3: "",
    userId: "",
    location: { id: "", city: "", description: "" },
    facility: [{ id: "", name: "", description: "" }],
  });

  const [booking, setBooking] = useState({
    userId: "",
    parkingId: "",
    checkIn: "",
    checkOut: "",
    totalRoom: "",
    totalDay: "",
  });

  const handleBookingInput = (e) => {
    setBooking({ ...booking, [e.target.name]: e.target.value });
  };

  const retrieveParking = async () => {
    const response = await axios.get(
      "http://localhost:8080/api/parking/id?parkingId=" + parkingId
    );

    return response.data;
  };

  useEffect(() => {
    const getParking = async () => {
      const retrievedParking = await retrieveParking();

      setParking(retrievedParking.parking);
    };

    const getParkingsByLocation = async () => {
      const allParkings = await retrieveParkingsByLocation();
      if (allParkings) {
        setParkings(allParkings.parkings);
      }
    };

    getParking();
    getParkingsByLocation();

    console.log("Print Parkings");
    console.log(parking.json);

    setFacilitiesToPass(parking.facility);
  }, [parkingId]);

  const retrieveParkingsByLocation = async () => {
    const response = await axios.get(
      "http://localhost:8080/api/parking/location?locationId=" + locationId
    );
    console.log(response.data);
    return response.data;
  };

  const saveProductToCart = (userId) => {
    fetch("http://localhost:8080/api/user/cart/add", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        quantity: quantity,
        userId: userId,
        parkingId: parkingId,
      }),
    }).then((result) => {
      console.log("result", result);

      toast.success("Products added to Cart Successfully!!!", {
        position: "top-center",
        autoClose: 1000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });

      result.json().then((res) => {
        console.log("response", res);
      });
    });
  };

  const bookParking = (e) => {
    if (user == null) {
      alert("Please login to book the parking slots!!!");
      e.preventDefault();
    } else {
      const formData = new FormData();
      formData.append("userId", user.id);
      formData.append("parkingId", parkingId);
      formData.append("checkIn", booking.checkIn);
      formData.append("checkOut", booking.checkOut);
      formData.append("totalRoom", booking.totalRoom);
      formData.append("totalDay", booking.totalDay);

      console.log(formData);

      axios
        .post("http://localhost:8080/api/book/parking/", formData)
        .then((result) => {
          result.json().then((res) => {
            console.log(res);
            console.log(res.responseMessage);
            alert("Slot Booked Successfully!!!");
          });
        });
    }
  };

  const navigateToAddParkingFacility = () => {
    navigate("/parking/" + parkingId + "/add/facility");
  };

  const navigateToAddReviewPage = () => {
    navigate("/parking/" + parkingId + "/location/" + locationId + "/add/review");
  };

  return (
    <div className="container-fluid mb-5">
      <div class="row">
        <div class="col-sm-3 mt-2">
          <div class="card form-card border-color custom-bg">
            <ParkingCarousel
              item={{
                image1: parking.image1,
                image2: parking.image2,
                image3: parking.image3,
              }}
            />
          </div>
        </div>
        <div class="col-sm-5 mt-2">
          <div class="card form-card border-color custom-bg">
            <div class="card-header bg-color">
              <div className="d-flex justify-content-between">
                <h1 className="custom-bg-text">{parking.name}</h1>
              </div>
            </div>

            <div class="card-body text-left text-color">
              <div class="text-left mt-3">
                <h3>Description :</h3>
              </div>
              <h4 class="card-text">{parking.description}</h4>
            </div>

            <div class="card-footer custom-bg">
              <div className="d-flex justify-content-between">
                <p>
                  <span>
                    <h4>Price : &#8377;{parking.pricePerDay}</h4>
                  </span>
                </p>

                <p class="text-color">
                  <b>Total Slots : {parking.totalRoom}</b>
                </p>
              </div>

              <div>
                <form class="row g-3" onSubmit={bookParking}>
                  <div class="col-auto">
                    <label for="checkin">In-time</label>
                    <input
                      type="date"
                      class="form-control"
                      id="checkin"
                      name="checkIn"
                      onChange={handleBookingInput}
                      value={booking.checkIn}
                      required
                    />
                  </div>
                  <div class="col-auto">
                    <label for="checkout">Out-Time</label>
                    <input
                      type="date"
                      class="form-control"
                      id="checkout"
                      name="checkOut"
                      onChange={handleBookingInput}
                      value={booking.checkOut}
                      required
                    />
                  </div>
                  <div class="col-auto">
                    <label for="totalroom">Total Slots</label>
                    <input
                      type="number"
                      class="form-control"
                      id="totalroom"
                      name="totalRoom"
                      onChange={handleBookingInput}
                      value={booking.totalRoom}
                      required
                    />
                  </div>
                  <div class="col-auto">
                    <label for="totalDay">Total Days</label>
                    <input
                      type="number"
                      class="form-control"
                      id="totalDay"
                      name="totalDay"
                      onChange={handleBookingInput}
                      value={booking.totalDay}
                      required
                    />
                  </div>

                  <div className="d-flex justify-content-center">
                    <div>
                      <input
                        type="submit"
                        class="btn custom-bg bg-color mb-3"
                        value="Book Parking"
                      />
                    </div>
                  </div>
                </form>
              </div>

              {(() => {
                if (admin) {
                  console.log(admin);
                  return (
                    <div>
                      <input
                        type="submit"
                        className="btn custom-bg bg-color mb-3"
                        value="Add Facilities"
                        onClick={navigateToAddParkingFacility}
                      />
                    </div>
                  );
                }
              })()}

              {(() => {
                if (user) {
                  console.log(user);
                  return (
                    <div>
                      <input
                        type="submit"
                        className="btn custom-bg bg-color mb-3"
                        value="Add Review"
                        onClick={navigateToAddReviewPage}
                      />
                    </div>
                  );
                }
              })()}
            </div>
          </div>
        </div>
        <div class="col-sm-2 mt-2">
          <GetParkingFacilities item={parking} />
        </div>

        <div class="col-sm-2 mt-2">
          <GetParkingReviews item={parking} />
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-sm-12">
          <h2>Other Parkings in {parking.location.city} Location:</h2>
          <div className="row row-cols-1 row-cols-md-4 g-4">
            {parkings.map((h) => {
              return <ParkingCard item={h} />;
            })}
          </div>
        </div>
      </div>
      <br />
      <hr />
      <Footer />
    </div>
  );
};

export default Parking;
