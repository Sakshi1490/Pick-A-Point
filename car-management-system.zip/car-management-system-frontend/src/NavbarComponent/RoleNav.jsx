import AdminHeader from "./AdminHeader";
import CustomerHeader from "./CustomerHeader";
import ParkingHeader from "./ParkingHeader";
import NormalHeader from "./NormalHeader";

const RoleNav = () => {
  const user = JSON.parse(sessionStorage.getItem("active-customer"));
  const admin = JSON.parse(sessionStorage.getItem("active-admin"));
  const parking = JSON.parse(sessionStorage.getItem("active-parking"));

  if (user != null) {
    return <CustomerHeader />;
  } else if (admin != null) {
    return <AdminHeader />;
  } else if (parking != null) {
    return <ParkingHeader />;
  } else {
    return <NormalHeader />;
  }
};

export default RoleNav;
