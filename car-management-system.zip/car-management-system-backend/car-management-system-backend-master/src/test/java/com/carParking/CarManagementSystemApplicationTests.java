package com.carParking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
