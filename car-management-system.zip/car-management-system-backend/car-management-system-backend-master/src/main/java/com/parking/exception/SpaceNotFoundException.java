package com.parking.exception;

import org.springframework.stereotype.Component;

@Component
public class SpaceNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
