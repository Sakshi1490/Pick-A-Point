package com.carparking.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carparking.entity.Parking;
import com.carparking.dto.CommanApiResponse;
import com.carparking.dto.ParkingAddRequest;
import com.carparking.dto.ParkingAddResponse;
import com.carparking.dto.ParkingResponseDto;
import com.carparking.entity.Location;
import com.carparking.entity.User;
import com.carparking.service.ParkingService;
import com.carparking.service.LocationService;
import com.carparking.service.UserService;
import com.carparking.utility.StorageService;
import com.carparking.utility.Constants.ResponseCode;
import com.parking.exception.SpaceNotFoundException;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("api/parking/")
@CrossOrigin(origins = "http://localhost:3000")
public class ParkingController {

	Logger LOG = LoggerFactory.getLogger(ParkingController.class);

	@Autowired
	private ParkingService parkingService;

	@Autowired
	private LocationService locationService;

	@Autowired
	private StorageService storageService;

	@Autowired
	private UserService userService;

	@PostMapping("add")
	@ApiOperation(value = "Api to add Parking")
	public ResponseEntity<?> register(ParkingAddRequest parkingAddRequest) {
		LOG.info("Recieved request for Add Parking");

		CommanApiResponse response = new CommanApiResponse();

		if (parkingAddRequest == null) {
			throw new SpaceNotFoundException();
		}

		if (parkingAddRequest.getLocationId() == 0) {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("parking Location is not selected");
			return new ResponseEntity(response, HttpStatus.BAD_REQUEST);
		}

		if (parkingAddRequest.getUserId() == 0) {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("parking Admin is not selected");
			return new ResponseEntity(response, HttpStatus.BAD_REQUEST);
		}

		Parking parking = ParkingAddRequest.toEntity(parkingAddRequest);
		Location location = locationService.getLocationById(parkingAddRequest.getLocationId());
		parking.setLocation(location);

		String image1 = storageService.store(parkingAddRequest.getImage1());
		String image2 = storageService.store(parkingAddRequest.getImage2());
		String image3 = storageService.store(parkingAddRequest.getImage3());
		parking.setImage1(image1);
		parking.setImage2(image2);
		parking.setImage3(image3);
		Parking addedParking = parkingService.addParking(parking);

		if (addedParking != null) {

			User parkingAdmin = userService.getUserById(parkingAddRequest.getUserId());
			parkingAdmin.setSpotId(addedParking.getId());
			this.userService.updateUser(parkingAdmin);

			response.setResponseCode(ResponseCode.SUCCESS.value());
			response.setResponseMessage("Parking Added Successfully");
			return new ResponseEntity(response, HttpStatus.OK);
		}

		else {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Failed to add the Space");
			return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("id")
	@ApiOperation(value = "Api to fetch parking by using spot Id")
	public ResponseEntity<?> fetchParking(@RequestParam("spotId") int spotId) {
		LOG.info("Recieved request for Fetch parking using spot Id");

		ParkingResponseDto response = new ParkingResponseDto();

		Parking parking = parkingService.fetchParking(spotId);

		if (parking == null) {
			throw new SpaceNotFoundException();
		}

		try {
			response.setParking(parking);
			response.setResponseCode(ResponseCode.SUCCESS.value());
			response.setResponseMessage("Parking Fetched Successfully");
			return new ResponseEntity(response, HttpStatus.OK);

		} catch (Exception e) {
			LOG.error("Exception Caught");
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Failed to Fetch parking");
			return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping("fetch")
	@ApiOperation(value = "Api to fetch all Parking")
	public ResponseEntity<?> fetchAllParkingSpaces() {
		LOG.info("Recieved request for Fetch parking");

		ParkingAddResponse parkingAddResponse = new ParkingAddResponse();

		List<Parking> parking = parkingService.fetchAllParking();
		try {
			parkingAddResponse.setParking(parking);
			parkingAddResponse.setResponseCode(ResponseCode.SUCCESS.value());
			parkingAddResponse.setResponseMessage("Parking Spaces Fetched Successfully");
			return new ResponseEntity(parkingAddResponse, HttpStatus.OK);

		} catch (Exception e) {
			LOG.error("Exception Caught");
			parkingAddResponse.setResponseCode(ResponseCode.FAILED.value());
			parkingAddResponse.setResponseMessage("Failed to Fetch Space");
			return new ResponseEntity(parkingAddResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping("location")
	@ApiOperation(value = "Api to fetch all Parking Space by using location Id")
	public ResponseEntity<?> getProductsByCategories(@RequestParam("locationId") int locationId) {

		System.out.println("request came for getting all Parking Spaces by locations");

		ParkingAddResponse parkingAddResponse = new ParkingAddResponse();

		List<Parking> parking = new ArrayList<Parking>();

		Location location = locationService.getLocationById(locationId);

		parking = this.parkingService.fetchParkingByLocation(location);

		try {
			parkingAddResponse.setParking(parking);
			parkingAddResponse.setResponseCode(ResponseCode.SUCCESS.value());
			parkingAddResponse.setResponseMessage("Parking Fetched Successfully");
			return new ResponseEntity(parkingAddResponse, HttpStatus.OK);

		} catch (Exception e) {
			LOG.error("Exception Caught");
			parkingAddResponse.setResponseCode(ResponseCode.FAILED.value());
			parkingAddResponse.setResponseMessage("Failed to Fetch Parking");
			return new ResponseEntity(parkingAddResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping(value = "/{parkingImageName}", produces = "image/*")
	@ApiOperation(value = "Api to fetch parking image by using image name")
	public void fetchProductImage(@PathVariable("parkingImageName") String parkingImageName, HttpServletResponse resp) {
		System.out.println("request came for fetching product pic");
		System.out.println("Loading file: " + parkingImageName);
		Resource resource = storageService.load(parkingImageName);
		if (resource != null) {
			try (InputStream in = resource.getInputStream()) {
				ServletOutputStream out = resp.getOutputStream();
				FileCopyUtils.copy(in, out);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		System.out.println("response sent!");
	}

}
