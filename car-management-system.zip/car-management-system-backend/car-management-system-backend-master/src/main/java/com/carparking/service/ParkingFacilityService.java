package com.carparking.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carparking.dao.ParkingFacilityDao;
import com.carparking.entity.ParkingFacility;

@Service
public class ParkingFacilityService {
	
	@Autowired
	private ParkingFacilityDao ParkingFacilityDao;
	
	public List<ParkingFacility> getParkingFacilitiesBySpotId(int spotId) {
		return this.ParkingFacilityDao.findBySpotId(spotId);
	}
	
	public ParkingFacility addFacility(ParkingFacility parkingFacility) {
	    return this.ParkingFacilityDao.save(parkingFacility);
	}

}
