package com.carparking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carparking.entity.Parking;
import com.carparking.entity.Location;

@Repository
public interface ParkingDao extends JpaRepository<Parking, Integer> {
	
	List<Parking> findByLocation(Location locationId);
	
}
