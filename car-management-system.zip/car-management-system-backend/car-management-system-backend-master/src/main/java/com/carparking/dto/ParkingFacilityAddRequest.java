package com.carparking.dto;

public class ParkingFacilityAddRequest {
	
	private int spotId;
	
	private int facilityId;

	public int getSpotId() {
		return spotId;
	}

	public void setHotelId(int hotelId) {
		this.spotId = hotelId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	} 
	
	
	
}
