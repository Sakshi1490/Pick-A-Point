package com.carparking.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carparking.dao.ParkingReviewDao;
import com.carparking.entity.ParkingReview;

@Service
public class ParkingReviewService {
	
	@Autowired
	private ParkingReviewDao parkingReviewDao;
	
	public ParkingReview addParkingReview(ParkingReview review) {
		return parkingReviewDao.save(review);
	}
	
	public List<ParkingReview> fetchParkingReviews(int spotId) {
		return parkingReviewDao.findBySpotId(spotId);
	}

}
