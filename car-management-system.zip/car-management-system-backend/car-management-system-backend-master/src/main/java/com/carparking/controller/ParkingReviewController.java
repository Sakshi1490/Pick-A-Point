package com.carparking.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carparking.dto.CommanApiResponse;
import com.carparking.dto.ParkingReviewDto;
import com.carparking.dto.ParkingReviewResponseDto;
import com.carparking.entity.ParkingReview;
import com.carparking.entity.User;
import com.carparking.service.ParkingReviewService;
import com.carparking.service.ParkingService;
import com.carparking.service.UserService;
import com.carparking.utility.Constants.ResponseCode;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("api/parking/review")
@CrossOrigin(origins = "http://localhost:3000")
public class ParkingReviewController {
	
	Logger LOG = LoggerFactory.getLogger(ParkingController.class);

	@Autowired
	private ParkingService parkingService;

	@Autowired
	private ParkingReviewService parkingReviewService;
	
    @Autowired
    private UserService userService;
	
	@PostMapping("add")
	@ApiOperation(value = "Api to add parking REVIEW")
	public ResponseEntity<?> register(@RequestBody ParkingReview review) {
		LOG.info("Recieved request for Add parking Review");

		CommanApiResponse response = new CommanApiResponse();

		if (review == null) {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Failed to add review");
			return new ResponseEntity(response, HttpStatus.BAD_REQUEST);
		}
		
		ParkingReview parkingReview = parkingReviewService.addParkingReview(review);
		
		if (parkingReview != null) {
			response.setResponseCode(ResponseCode.SUCCESS.value());
			response.setResponseMessage("Parking Review Added Successfully");
			return new ResponseEntity(response, HttpStatus.OK);
		}

		else {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Failed to add Parking");
			return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("fetch")
	@ApiOperation(value = "Api to fetch all reviews of parking")
	public ResponseEntity<?> fetchParkingReview(@RequestParam("spotId") int spotId) {
		LOG.info("Recieved request for Fetch Parking Reviews for Spot Id : "+ spotId);

		ParkingReviewResponseDto response = new ParkingReviewResponseDto();

		List<ParkingReview> reviews = parkingReviewService.fetchParkingReviews(spotId);
		
		List<ParkingReviewDto> reviewDto = new ArrayList<>();
		
		for(ParkingReview review : reviews) {
			
			User user = userService.getUserById(review.getUserId());
			
			reviewDto.add(new ParkingReviewDto(user.getFirstName(), review.getStar(), review.getReview()));
			
		}
		
		
		try {
			response.setParkingReviews(reviewDto);
			response.setResponseCode(ResponseCode.SUCCESS.value());
			response.setResponseMessage("Parking Reviews Fetched Successfully");
			return new ResponseEntity(response, HttpStatus.OK);

		} catch (Exception e) {
			LOG.error("Exception Caught");
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Failed to Fetch Parking Reviews");
			return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
}
