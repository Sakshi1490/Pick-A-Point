package com.carparking.dto;

import com.carparking.entity.Parking;

public class ParkingResponseDto extends CommanApiResponse {
	
	private Parking parking;

	public Parking getParking() {
		return parking;
	}

	public void setParking(Parking parking) {
		this.parking = parking;
	}
	
	

}
