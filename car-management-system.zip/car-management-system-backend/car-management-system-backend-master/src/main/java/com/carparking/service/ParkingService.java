package com.carparking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carparking.entity.Parking;
import com.carparking.dao.ParkingDao;
import com.carparking.entity.Location;

@Service
public class ParkingService {

	@Autowired
	private ParkingDao parkingDao;

	public Parking addParking(Parking parking) {
		return parkingDao.save(parking);
	}
	
	public List<Parking> fetchAllParking() {
		return parkingDao.findAll();
	}
	
	public List<Parking> fetchParkingByLocation(Location locationId) {
		return parkingDao.findByLocation(locationId);
	}
	
	public Parking fetchParking(int parkingId) {
		return parkingDao.findById(parkingId).get();
	}

}
