package com.carparking.dto;

public class BookingDto {

	private int id;

	private String bookingId;

	private int userId;

	private String customerName;

	private String checkIn;

	private String checkOut;

	private String status;

	private int spotId;

	private int totalSpace;

	private int totalHours;

	private String parkingContact;

	private String parkingEmail;

	private String parkingImage;

	private String parkingSpaceName;

	private String customerContact;

	private String totalAmount;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}

	public String getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getSpotId() {
		return spotId;
	}

	public void setSpotId(int spotId) {
		this.spotId = spotId;
	}

	public int getTotalSpace() {
		return totalSpace;
	}

	public void setTotalSpace(int totalSpace) {
		this.totalSpace = totalSpace;
	}

	public int getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(int totalHours) {
		this.totalHours = totalHours;
	}

	public String getParkingContact() {
		return parkingContact;
	}

	public void setParkingContact(String parkingContact) {
		this.parkingContact = parkingContact;
	}

	public String getParkingEmail() {
		return parkingEmail;
	}

	public void setParkingEmail(String parkingEmail) {
		this.parkingEmail = parkingEmail;
	}

	public String getParkingImage() {
		return parkingImage;
	}

	public void setParkingImage(String parkingImage) {
		this.parkingImage = parkingImage;
	}

	public String getParkingSpaceName() {
		return parkingSpaceName;
	}

	public void setParkingSpaceName(String parkingSpaceName) {
		this.parkingSpaceName = parkingSpaceName;
	}

	public String getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

}
