package com.carparking.dto;

import java.util.List;

public class ParkingReviewResponseDto extends CommanApiResponse {
	
	private List<ParkingReviewDto> parkingReviews;

	public List<ParkingReviewDto> getParkingReviews() {
		return parkingReviews;
	}

	public void setParkingReviews(List<ParkingReviewDto> parkingReviews) {
		this.parkingReviews = parkingReviews;
	}
	
	

}
