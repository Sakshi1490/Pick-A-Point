package com.carparking.dto;

import java.util.List;

import com.carparking.entity.Parking;

public class ParkingAddResponse extends CommanApiResponse {

	List<Parking> parking;

	public List<Parking> getParking() {
		return parking;
	}

	public void setParking(List<Parking> parking) {
		this.parking = parking;
	}
	
	
	
}
