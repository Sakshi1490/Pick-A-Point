package com.carparking.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carparking.dto.CommanApiResponse;
import com.carparking.dto.FacilityFetchResponse;
import com.carparking.dto.ParkingFacilityAddRequest;
import com.carparking.entity.Facility;
import com.carparking.entity.Parking;
import com.carparking.entity.ParkingFacility;
import com.carparking.service.FacilityService;
import com.carparking.service.ParkingFacilityService;
import com.carparking.service.ParkingService;
import com.carparking.utility.Constants.ResponseCode;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("api/facility/")
@CrossOrigin(origins = "http://localhost:3000")
public class FacilityController {
	
	Logger LOG = LoggerFactory.getLogger(FacilityController.class);

	@Autowired
	private FacilityService facilityService;
	
	@Autowired
	private ParkingService parkingService;

	@Autowired
	private ParkingFacilityService FacilityService;
	
	
	@PostMapping("add")
	@ApiOperation(value = "Api to add facility")
	public ResponseEntity<?> register(@RequestBody Facility facility) {
		LOG.info("Recieved request for Add Facility");

		CommanApiResponse response = new CommanApiResponse();

		Facility addedFacility = facilityService.addFacility(facility);

		if (addedFacility != null) {
			response.setResponseCode(ResponseCode.SUCCESS.value());
			response.setResponseMessage("Facility Added Successfully");
			return new ResponseEntity(response, HttpStatus.OK);
		}

		else {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Failed to add Facility");
			return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("fetch")
	@ApiOperation(value = "Api to fetch all facilities")
	public ResponseEntity<?> fetchAllFacilities() {
		LOG.info("Recieved request for Fetch Facility");

		FacilityFetchResponse facilityFetchResponse = new FacilityFetchResponse();

		Set<Facility> facilities = facilityService.fetchAllFacilities();

		try {
			facilityFetchResponse.setFacilities(facilities);
			facilityFetchResponse.setResponseCode(ResponseCode.SUCCESS.value());
			facilityFetchResponse.setResponseMessage("Facilities Fetched Successfully");
			return new ResponseEntity(facilityFetchResponse, HttpStatus.OK);

		} catch (Exception e) {
			LOG.error("Exception Caught");
			facilityFetchResponse.setResponseCode(ResponseCode.FAILED.value());
			facilityFetchResponse.setResponseMessage("Failed to Fetch Facility");
			return new ResponseEntity(facilityFetchResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@GetMapping("/parking")
	@ApiOperation(value = "Api to fetch all facilities of hotel by using hotel Id")
	public ResponseEntity<?> fetchAllFacilitiesByHotelId(@RequestParam("spotId") int spotId) {
		LOG.info("Recieved request for Fetch Facility");

		FacilityFetchResponse facilityFetchResponse = new FacilityFetchResponse();

		List<ParkingFacility> parkingFacilities = this.FacilityService.getParkingFacilitiesBySpotId(spotId);
		
		Set<Facility> facilities = new HashSet<>();
		
		for(ParkingFacility parkingFacility: parkingFacilities) {
			facilities.add(this.facilityService.getFacilityById(parkingFacility.getFacilityId()));
		}

		try {
			facilityFetchResponse.setFacilities(facilities);
			facilityFetchResponse.setResponseCode(ResponseCode.SUCCESS.value());
			facilityFetchResponse.setResponseMessage("Facilities Fetched Successfully");
			
			System.out.println(facilityFetchResponse);
			
			return new ResponseEntity(facilityFetchResponse, HttpStatus.OK);

		} catch (Exception e) {
			LOG.error("Exception Caught");
			facilityFetchResponse.setResponseCode(ResponseCode.FAILED.value());
			facilityFetchResponse.setResponseMessage("Failed to Fetch Facility");
			return new ResponseEntity(facilityFetchResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@PostMapping("/parking/add")
	@ApiOperation(value = "Api to add facility to Hotel")
	public ResponseEntity<?> addHotelFacility(@RequestBody ParkingFacilityAddRequest addFacility) {
		LOG.info("Recieved request for Add Facility");

		CommanApiResponse response = new CommanApiResponse();

		Facility facility = facilityService.getFacilityById(addFacility.getFacilityId());
		
		if(facility == null) {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Facility not found");
			return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
        List<ParkingFacility> parkingFacilities = this.FacilityService.getParkingFacilitiesBySpotId(addFacility.getSpotId());
		
		Set<Facility> facilities = new HashSet<>();
		
		for(ParkingFacility parkingFacility: parkingFacilities) {	
			if(parkingFacility.getFacilityId() == facility.getId()) {
				response.setResponseCode(ResponseCode.FAILED.value());
				response.setResponseMessage("Facility already added");
				return new ResponseEntity(response, HttpStatus.BAD_REQUEST);
			}
		}
		
		ParkingFacility parkingFacility = new ParkingFacility();
		parkingFacility.setSpotId(addFacility.getSpotId());
		parkingFacility.setFacilityId(addFacility.getFacilityId());

		parkingFacilities.add(parkingFacility);
		
		
		ParkingFacility addedParkingFacility = FacilityService.addFacility(parkingFacility);
		
		if (addedParkingFacility != null) {
			response.setResponseCode(ResponseCode.SUCCESS.value());
			response.setResponseMessage("Parking Facility Added Successfully");
			return new ResponseEntity(response, HttpStatus.OK);
		}

		else {
			response.setResponseCode(ResponseCode.FAILED.value());
			response.setResponseMessage("Failed to add Parking Facility");
			return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
